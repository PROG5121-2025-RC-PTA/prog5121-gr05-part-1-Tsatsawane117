package chatapp;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.util.*;

public class MessageHandler{

    // Message structure with readable formatting
    static class Message {
        String recipient;
        String content;
        String messageID;
        String messageHash;
        String status;

        private static int totalMessages = 0;

        public Message(String recipient, String content, String status) {
            this.recipient = recipient;
            this.content = content;
            this.status = status;
            this.messageID = generateUniqueID();
            this.messageHash = generateHash();
            totalMessages++;
        }

        private String generateUniqueID() {
            Random rand = new Random();
            StringBuilder id = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                id.append(rand.nextInt(10));
            }
            return id.toString();
        }

        private String generateHash() {
            String[] words = content.split("\\s+");
            String first = words.length > 0 ? words[0] : "";
            String last = words.length > 1 ? words[words.length - 1] : "";
            return messageID.substring(0, 2) + ":" + totalMessages + ":" + (first + last).toUpperCase();
        }

        public String toFormattedString() {
            return "📩 Message ID: " + messageID +
                    "\n🔒 Message Hash: " + messageHash +
                    "\n📞 To: " + recipient +
                    "\n📝 Message: " + content +
                    "\n📦 Status: " + status;
        }
    }

    // Message handler: storage, search, delete, and reports
    static class Message {
        private static final String FILE_PATH = "messages.json";
        private static final Gson gson = new Gson();

        public static void storeMessage(Message message) {
            List<Message> messages = loadMessages();
            messages.add(message);
            saveMessages(messages);
        }

        public static List<Message> loadMessages() {
            try (Reader reader = new FileReader(FILE_PATH)) {
                return gson.fromJson(reader, new TypeToken<List<Message>>() {}.getType());
            } catch (IOException e) {
                return new ArrayList<>();
            }
        }

        private static void saveMessages(List<Message> messages) {
            try (Writer writer = new FileWriter(FILE_PATH)) {
                gson.toJson(messages, writer);
            } catch (IOException e) {
                System.out.println("⚠️ Could not save messages.");
            }
        }

        public static Message findMessageByID(String id) {
            for (Message m : loadMessages()) {
                if (m.messageID.equals(id)) return m;
            }
            return null;
        }

        public static List<Message> findMessagesByRecipient(String recipient) {
            List<Message> results = new ArrayList<>();
            for (Message m : loadMessages()) {
                if (m.recipient.equals(recipient)) results.add(m);
            }
            return results;
        }

        public static boolean deleteMessageByHash(String hash) {
            List<Message> messages = loadMessages();
            boolean removed = messages.removeIf(m -> m.messageHash.equals(hash));
            if (removed) saveMessages(messages);
            return removed;
        }

        public static Message findLongestMessage() {
            return loadMessages().stream()
                    .max(Comparator.comparingInt(m -> m.content.length()))
                    .orElse(null);
        }

        public static void printSentMessageReport() {
            System.out.println("=== Sent Message Report ===");
            for (Message m : loadMessages()) {
                if (m.status.equalsIgnoreCase("send")) {
                    System.out.println(m.toFormattedString());
                    System.out.println("----------------------------------------");
                }
            }
        }
    }

    // real-life simulation using test data
    public static void main(String[] args) {
        System.out.println("🚀 Welcome to QuickChat Message Manager");

        // Setup with test messages (like a real case scenario)
        Message[] testMessages = {
                new Message("+27834557896", "Did you get the cake?", "Send"),
                new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Store"),
                new Message("+27834484567", "Yohoooo, I am at your gate.", "Discard"),
                new Message("0838884567", "It is dinner time !", "Send"),
                new Message("+27838884567", "Ok, I am leaving without you.", "Store")
        };

        // Store messages
        for (Message msg : testMessages) {
            MessageHandler.storeMessage(msg);
        }

        // Display all sent messages
        MessageHandler.printSentMessageReport();

        // Longest message
        Message longest = MessageHandler.findLongestMessage();
        if (longest != null) {
            System.out.println(" Longest Message:\n" + longest.content);
        }

        // Search by ID
        String idToFind = testMessages[3].messageID;
        Message foundByID = MessageHandler.findMessageByID(idToFind);
        System.out.println("Search by Message ID (" + idToFind + "):");
        if (foundByID != null) System.out.println(foundByID.content);

        // Search messages by recipient
        System.out.println(" Messages sent to +27838884567:");
        for (Message m : MessageHandler.findMessagesByRecipient("+27838884567")) {
            System.out.println("- " + m.content);
        }

        // Delete a message by hash
        String hashToDelete = testMessages[1].messageHash;
        if (MessageHandler.deleteMessageByHash(hashToDelete)) {
            System.out.println("️ Message \"" + testMessages[1].content + "\" successfully deleted.");
        }

        // Final report
        System.out.println("Final Sent Message Report:");
        MessageHandler.printSentMessageReport();
    }
}