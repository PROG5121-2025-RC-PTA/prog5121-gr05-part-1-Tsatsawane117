package chatapp;

import java.util.regex.*;

public class Login {
    private String username;
    private String password;
    private String cellNumber;

    // Constructor
    public Login(String username, String password, String cellNumber) {
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
    }

    // Username must contain an underscore and be no more than 5 characters
    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    // Password complexity check
    public boolean checkPasswordComplexity() {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*[0-9].*") &&
               password.matches(".*[!@#\\$%\\^&\\*()\\-+=].*");
    }

    // Validates SA phone number with country code using regex
    // Referenced: ChatGPT (OpenAI, 2025). Generated regex logic.
    public boolean checkCellPhoneNumber() {
        return Pattern.matches("^\\+27\\d{9}$", cellNumber);
    }

    // Registration response message
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        return "User registered successfully.";
    }

    // Authenticates user
    public boolean loginUser(String inputUsername, String inputPassword) {
        return this.username.equals(inputUsername) && this.password.equals(inputPassword);
    }

    // Returns login status message
    public String returnLoginStatus(boolean isLoggedIn, String firstName, String lastName) {
        return isLoggedIn ?
            "Welcome " + firstName + ", " + lastName + " it is great to see you again." :
            "Username or password incorrect, please try again.";
    }
}