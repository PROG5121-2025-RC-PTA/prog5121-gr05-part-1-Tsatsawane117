package chatapp;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;

public class ChatApp {

//Login 
static class Login {
    private String username;
    private String password;
    private String cellNumber;

    public Login(String username, String password, String cellNumber) {
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
    }

    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*[0-9].*") &&
               password.matches(".*[!@#\\$%\\^&\\*()\\-+=].*");
    }

    public boolean checkCellPhoneNumber() {
        return Pattern.matches("^\\+27\\d{9}$", cellNumber);
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        return "User registered successfully.";
    }

    public boolean loginUser(String inputUsername, String inputPassword) {
        return this.username.equals(inputUsername) && this.password.equals(inputPassword);
    }

    public String returnLoginStatus(boolean loggedIn, String firstName, String lastName) {
        return loggedIn ?
            "Welcome " + firstName + ", " + lastName + " it is great to see you again." :
            "Username or password incorrect, please try again.";
    }
}

// Message Class 
static class Message {
    private static int count = 0;
    public String recipient;
    public String messageText;
    public String messageID;
    public String messageHash;
    public String status;

    public Message(String recipient, String messageText, String status) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.status = status;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
        count++;
    }

    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public boolean checkRecipientCell() {
        return recipient.matches("^\\+27\\d{9}$");
    }

    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : "";
        return messageID.substring(0, 2) + ":" + count + ":" + (first + last).toUpperCase();
    }

    public String sendMessage(String choice) {
        switch (choice.toLowerCase()) {
            case "send": return "Message successfully sent.";
            case "discard": return "Press 0 to delete message.";
            case "store": return "Message successfully stored.";
            default: return "Invalid option.";
        }
    }

    public String printMessage() {
        return "Message ID: " + messageID + "\nMessage Hash: " + messageHash +
               "\nRecipient: " + recipient + "\nMessage: " + messageText +
               "\nStatus: " + status;
    }
}

//Message Handler
static class MessageHandler {
    private static final String FILE_PATH = "messages.json";
    private static final Gson gson = new Gson();

    public static void storeMessage(Message msg) throws IOException {
        List<Message> messages = loadMessages();
        messages.add(msg);
        saveMessages(messages);
    }

    public static List<Message> loadMessages() throws FileNotFoundException, IOException {
        try (Reader reader = new FileReader(FILE_PATH)) {
            return gson.fromJson(reader, new TypeToken<List<Message>>() {}.getType());
        }    }

    private static void saveMessages(List<Message> messages) {
        try (Writer writer = new FileWriter(FILE_PATH)) {
            gson.toJson(messages, writer);
        } catch (IOException e) {
            System.out.println("Failed to save messages.");
        }
    }

    public static Message findByMessageID(String id) throws IOException {
        for (Message m : loadMessages()) {
            if (m.messageID.equals(id)) return m;
        }
        return null;
    }

    public static List<Message> findByRecipient(String recipient) throws IOException {
        List<Message> results = new ArrayList<>();
        for (Message m : loadMessages()) {
            if (m.recipient.equals(recipient)) results.add(m);
        }
        return results;
    }

    public static boolean deleteByHash(String hash) throws IOException {
        List<Message> messages = loadMessages();
        boolean removed = messages.removeIf(m -> m.messageHash.equals(hash));
        saveMessages(messages);
        return removed;
    }

    public static Message findLongestMessage() throws IOException {
        return loadMessages().stream()
            .max(Comparator.comparingInt(m -> m.messageText.length()))
            .orElse(null);
    }

    public static void printReport() throws IOException {
        for (Message m : loadMessages()) {
            if (m.status.equalsIgnoreCase("Send")) {
                System.out.println(m.printMessage());
                System.out.println("------------------------");
            }
        }
    }
}

//  Main App Entry
public static void main(String[] args) throws IOException {
    Scanner sc = new Scanner(System.in);

    // Registration
    System.out.print("Enter username: ");
    String username = sc.nextLine();
    System.out.print("Enter password: ");
    String password = sc.nextLine();
    System.out.print("Enter phone number (+27...): ");
    String phone = sc.nextLine();

    Login user = new Login(username, password, phone);
    System.out.println(user.registerUser());

    // Login
    System.out.print("\nLogin - Enter username: ");
    String u = sc.nextLine();
    System.out.print("Enter password: ");
    String p = sc.nextLine();
    boolean loggedIn = user.loginUser(u, p);
    System.out.println(user.returnLoginStatus(loggedIn, "Phindulo", "Student"));

    if (!loggedIn) return;

    System.out.println("\nWelcome to QuickChat");
    System.out.print("How many messages would you like to enter? ");
    int total = sc.nextInt(); sc.nextLine();

    for (int i = 0; i < total; i++) {
        System.out.println("\nMessage " + (i + 1));
        System.out.print("Recipient number (+27...): ");
        String rec = sc.nextLine();
        System.out.print("Enter your message: ");
        String msg = sc.nextLine();

        if (msg.length() > 250) {
            System.out.println("Message exceeds 250 characters by " + (msg.length() - 250));
            i--; continue;
        }

        Message m = new Message(rec, msg, "Pending");
        if (!m.checkRecipientCell()) {
            System.out.println("Invalid recipient format. Try again.");
            i--; continue;
        }

        System.out.print("Send, Store or Discard? ");
        String option = sc.nextLine();
        String result = m.sendMessage(option);
        m.status = option;

        if (option.equalsIgnoreCase("store")) MessageHandler.storeMessage(m);
        if (option.equalsIgnoreCase("send")) MessageHandler.storeMessage(m);

        System.out.println(result);
        System.out.println(m.printMessage());
    }

    System.out.println("\nTotal messages handled: " + MessageHandler.loadMessages().size());
    System.out.println("\nLongest Message:");
    Message longest = MessageHandler.findLongestMessage();
    if (longest != null) System.out.println(longest.messageText);

    System.out.print("\nSearch messages by recipient: ");
    String rSearch = sc.nextLine();
    List<Message> found = MessageHandler.findByRecipient(rSearch);
    found.forEach(m -> System.out.println(m.messageText));

    System.out.print("\nDelete message by hash: ");
    String hash = sc.nextLine();
    boolean deleted = MessageHandler.deleteByHash(hash);
    System.out.println(deleted ? "Message deleted." : "Not found.");

    System.out.println("\nSent Message Report:");
    MessageHandler.printReport();

    sc.close();
}

}