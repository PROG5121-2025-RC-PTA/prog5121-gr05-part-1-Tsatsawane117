package chatapp;

import java.util.Random;


public class Message {
    private static int count = 0;
    public String recipient;
    public String messageText;
    public String messageID;
    public String messageHash;
    public String status;
    public Object content;
     
    public Message(String recipient, String messageText, String status) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.status = status;
        this.messageID = generateID();
        this.messageHash = createMessageHash();
        count++;
    }

    private String generateID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public boolean checkRecipientCell() {
        return recipient.matches("^\\+27\\d{9}$");
    }

    public String createMessageHash() {
        String[] words = messageText.split("\\s+");
        String first = words[0];
        String last = words[words.length - 1];
        return messageID.substring(0, 2) + ":" + count + ":" + (first + last).toUpperCase();
    }

    public String sendMessage(String option) {
        switch (option.toLowerCase()) {
            case "send": return "Message successfully sent.";
            case "store": return "Message successfully stored.";
            case "discard": return "Press 0 to delete message.";
            default: return "Invalid option.";
        }
    }

}