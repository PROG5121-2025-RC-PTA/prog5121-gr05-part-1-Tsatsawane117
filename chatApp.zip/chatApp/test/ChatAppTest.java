import chatapp.Login;
import chatapp.Message;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
import java.io.*;

public class ChatAppTest {

    // PART 1: REGISTRATION AND LOGIN
    @Test
    public void testValidUsername() {
        Login login = new Login("abc_1", "Test@123", "+27831234567");
        assertTrue(login.checkUserName());
    }

    @Test
    public void testInvalidUsername() {
        Login login = new Login("invalidUsername", "Test@123", "+27831234567");
        assertFalse(login.checkUserName());
    }

    @Test
    public void testValidPassword() {
        Login login = new Login("abc_1", "Ch&&sec@ke99!", "+27831234567");
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testInvalidPassword() {
        Login login = new Login("abc_1", "password", "+27831234567");
        assertFalse(login.checkPasswordComplexity());
    }

    @Test
    public void testValidPhoneNumber() {
        Login login = new Login("abc_1", "Test@123", "+27834567890");
        assertTrue(login.checkCellPhoneNumber());
    }

    @Test
    public void testInvalidPhoneNumber() {
        Login login = new Login("abc_1", "Test@123", "08966553");
        assertFalse(login.checkCellPhoneNumber());
    }

    @Test
    public void testSuccessfulLogin() {
        Login login = new Login("abc_1", "Pass@123", "+27834567890");
        assertTrue(login.loginUser("abc_1", "Pass@123"));
    }

    @Test
    public void testFailedLogin() {
        Login login = new Login("abc_1", "Pass@123", "+27834567890");
        assertFalse(login.loginUser("wrong", "wrongpass"));
    }

    // PART 2: MESSAGE CREATION AND VALIDATION
    @Test
    public void testMessageLengthValid() {
        String shortMessage = "Hi Mike, can you join us for dinner tonight";
        assertTrue(shortMessage.length() <= 250);
    }

    @Test
    public void testMessageLengthInvalid() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 300; i++) sb.append("a");
        assertTrue(sb.toString().length() > 250);
    }

    @Test
    public void testValidRecipientCell() {
        Message msg = new Message("+27718693002", "Hello world!", "Send");
        assertTrue(msg.checkRecipientCell());
    }

    @Test
    public void testInvalidRecipientCell() {
        Message msg = new Message("08575975889", "Hello world!", "Send");
        assertFalse(msg.checkRecipientCell());
    }

    @Test
    public void testMessageHashFormat() {
        Message msg = new Message("+27718693002", "Hi thanks", "Send");
        String hash = msg.createMessageHash();
        assertTrue(hash.matches("^\\d{2}:\\d+:[A-Z]+$"));
    }

    // PART 3: STORAGE, SEARCH, DELETE, REPORTING
    static Message testMsg1, testMsg2;

    @BeforeAll
    public static void setup() {
        // Clear messages.json file
        try (PrintWriter writer = new PrintWriter("messages.json")) {
            writer.write("[]");
        } catch (IOException e) {
            e.printStackTrace();
        }

        testMsg1 = new Message("+27834557896", "Did you get the cake?", "Send");
        testMsg2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Store");

        MessageHandler.storeMessage(testMsg1);
        MessageHandler.storeMessage(testMsg2);
    }

    @Test
    public void testStoreAndLoadMessages() {
        List<Message> messages = MessageHandler.loadMessages();
        assertTrue(messages.size() >= 2);
    }

    @Test
    public void testFindByMessageID() {
        Message found = MessageHandler.findMessageByID(testMsg1.messageID);
        assertNotNull(found);
        assertEquals(testMsg1.messageText, found);
    }

    @Test
    public void testFindByRecipient() {
        List<Message> results = MessageHandler.findMessagesByRecipient("+27838884567");
        assertTrue(results.stream().anyMatch(m -> m.content.contain("Where are you?")));
    }

    @Test
    public void testDeleteMessageByHash() {
        boolean deleted = MessageHandler.deleteMessageByHash(testMsg2.messageHash);
        assertTrue(deleted);
    }

    @Test
    public void testLongestMessage() {
        Message longest = MessageHandler.findLongestMessage();
        assertNotNull(longest);
        assertEquals(testMsg1.messageText.length() > testMsg2.messageText.length() ? testMsg1.content : testMsg2.content, longest.content);
    }
