import chatapp.Message;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
import java.io.*;

public class MessageHandler {

    static Message test1, test2, test3;

    @BeforeAll
    public static void init() {
        // Clear previous data
        try (PrintWriter writer = new PrintWriter("messages.json")) {
            writer.write("[]");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Setup known test messages
        test1 = new Message("+27834557896", "Did you get the cake?", "Send");
        test2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Store");
        test3 = new Message("+27838884567", "Ok, I am leaving without you.", "Store");

        MessageHandler.storeMessage(test1);
        MessageHandler.storeMessage(test2);
        MessageHandler.storeMessage(test3);
    }

    static void storeMessage(Message test1) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static List<Message> loadMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static Message findMessageByID(String messageID) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static List<Message> findMessagesByRecipient(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static Message findLongestMessage() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static boolean deleteMessageByHash(String messageHash) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
    @Test
    public void testStoredMessagesLoadedCorrectly() {
        List<Message> messages = MessageHandler.loadMessages();
        assertTrue(messages.size() >= 3);
    }

    @Test
    public void testSearchByMessageID() {
        Message result = MessageHandler.findMessageByID(test1.messageID);
        assertNotNull(result);
        assertEquals(test1.content, result.content);
    }

    @Test
    public void testSearchByRecipient() {
        List<Message> results = MessageHandler.findMessagesByRecipient("+27838884567");
        assertEquals(2, results.size());
        assertTrue(results.stream().anyMatch(m -> m.content.equals(test2.content)));
    }

    @Test
    public void testDeleteMessageByHash() {
        boolean deleted = MessageHandler.deleteMessageByHash(test2.messageHash);
        assertTrue(deleted);
    }

    @Test
    public void testLongestMessageFound() {
        Message longest = MessageHandler.findLongestMessage();
        assertNotNull(longest);
        assertTrue(longest.content.length() >= test1.content.length());
    }

    @Test
    public void testFinalReportIncludesSentMessagesOnly() {
        List<Message> all = MessageHandler.loadMessages();
        boolean allSentMessagesPrinted = all.stream()
                .filter(m -> m.status.equalsIgnoreCase("Send"))
                .allMatch(m -> m.toFormattedString().contains(m.messageID));
        assertTrue(allSentMessagesPrinted);
    }
}

