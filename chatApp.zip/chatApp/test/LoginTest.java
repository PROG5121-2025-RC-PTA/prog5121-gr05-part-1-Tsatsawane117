import chatapp.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    // Test: Username is correctly formatted (e.g., "kyl_1")
    @Test
    public void testValidUsername() {
        Login login = new Login("kyl_1", "Test@123", "+27831234567");
        assertTrue(login.checkUserName());
    }

    // Test: Username is incorrectly formatted (e.g., "kyle!!!!!!!")
    @Test
    public void testInvalidUsername() {
        Login login = new Login("kyle!!!!!!!", "Test@123", "+27831234567");
        assertFalse(login.checkUserName());
    }

    // Test: Password meets complexity requirements (e.g., "Ch&&sec@ke99!")
    @Test
    public void testPasswordMeetsComplexity() {
        Login login = new Login("user_1", "Ch&&sec@ke99!", "+27831234567");
        assertTrue(login.checkPasswordComplexity());
    }

    // Test: Password does not meet complexity requirements (e.g., "password")
    @Test
    public void testPasswordFailsComplexity() {
        Login login = new Login("user_1", "password", "+27831234567");
        assertFalse(login.checkPasswordComplexity());
    }

    // Test: Cell phone number is correctly formatted (e.g., "+27838968976")
    @Test
    public void testValidCellPhoneNumber() {
        Login login = new Login("user_1", "Test@123", "+27838968976");
        assertTrue(login.checkCellPhoneNumber());
    }

    // Test: Cell phone number is incorrectly formatted (e.g., "08966553")
    @Test
    public void testInvalidCellPhoneNumber() {
        Login login = new Login("user_1", "Test@123", "08966553");
        assertFalse(login.checkCellPhoneNumber());
    }

    // Test: Registration message when all inputs are valid
    @Test
    public void testSuccessfulRegistration() {
        Login login = new Login("u_123", "Pass@123", "+27831234567");
        String message = login.registerUser();
        assertEquals("User registered successfully.", message);
    }

    // Test: Registration message when username is invalid
    @Test
    public void testInvalidUsernameRegistrationMessage() {
        Login login = new Login("username", "Pass@123", "+27831234567");
        String message = login.registerUser();
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", message);
    }

    // Test: Registration message when password is invalid
    @Test
    public void testInvalidPasswordRegistrationMessage() {
        Login login = new Login("u_12", "pass", "+27831234567");
        String message = login.registerUser();
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", message);
    }

    // Test: Successful login
    @Test
    public void testSuccessfulLogin() {
        Login login = new Login("abc_1", "Pass@123", "+27834567890");
        assertTrue(login.loginUser("abc_1", "Pass@123"));
    }

    // Test: Failed login
    @Test
    public void testFailedLogin() {
        Login login = new Login("abc_1", "Pass@123", "+27834567890");
        assertFalse(login.loginUser("wrong", "wrongpass"));
    }

    // Test: Login success message
    @Test
    public void testLoginStatusSuccessMessage() {
        Login login = new Login("abc_1", "Pass@123", "+27834567890");
        boolean status = login.loginUser("abc_1", "Pass@123");
        String msg = login.returnLoginStatus(status, "Phindulo", "Student");
        assertEquals("Welcome Phindulo, Student it is great to see you again.", msg);
    }

    // Test: Login failure message
    @Test
    public void testLoginStatusFailureMessage() {
        Login login = new Login("abc_1", "Pass@123", "+27834567890");
        boolean status = login.loginUser("user", "bad");
        String msg = login.returnLoginStatus(status, "Phindulo", "Student");
        assertEquals("Username or password incorrect, please try again.", msg);
    }
}