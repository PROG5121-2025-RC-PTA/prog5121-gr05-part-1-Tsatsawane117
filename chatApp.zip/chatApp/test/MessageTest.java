import chatapp.Message;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    // Test that message length is within limit (250 characters)
    @Test
    public void testMessageWithinLimit() {
        String shortMsg = "Hi Mike, can you join us for dinner tonight";
        assertTrue(shortMsg.length() <= 250);
    }

    // Test that message exceeds limit
    @Test
    public void testMessageExceedsLimit() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 260; i++) sb.append("x");
        String longMsg = sb.toString();
        assertTrue(longMsg.length() > 250);
    }

    // Valid recipient number (starts with +27 and 10 digits)
    @Test
    public void testValidRecipientNumber() {
        Message msg = new Message("+27718693002", "Hello there!", "Send");
        assertTrue(msg.checkRecipientCell());
    }

    // Invalid recipient number
    @Test
    public void testInvalidRecipientNumber() {
        Message msg = new Message("08575975889", "Hello there!", "Send");
        assertFalse(msg.checkRecipientCell());
    }

    // Message hash format test (e.g., 00:1:HITHERE)
    @Test
    public void testMessageHashFormat() {
        Message msg = new Message("+27718693002", "Hi there", "Send");
        String hash = msg.createMessageHash();
        assertTrue(hash.matches("^\\d{2}:\\d+:[A-Z]+$"));
    }

    // Check correct message hash with known values
    @Test
    public void testMessageHashCorrectness() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight", "Send");
        String hash = msg.createMessageHash();
        String[] parts = hash.split(":");
        assertEquals(3, parts.length);
        assertTrue(parts[2].startsWith("HIMIKE") || parts[2].startsWith("HITONIGHT")); // Acceptable variation
    }

    // Send message choice: Send
    @Test
    public void testSendMessageOptionSend() {
        Message msg = new Message("+27718693002", "Hello!", "Send");
        String result = msg.sendMessage("send");
        assertEquals("Message successfully sent.", result);
    }

    // Send message choice: Discard
    @Test
    public void testSendMessageOptionDiscard() {
        Message msg = new Message("+27718693002", "Hello!", "Discard");
        String result = msg.sendMessage("discard");
        assertEquals("Press 0 to delete message.", result);
    }

    // Send message choice: Store
    @Test
    public void testSendMessageOptionStore() {
        Message msg = new Message("+27718693002", "Hello!", "Store");
        String result = msg.sendMessage("store");
        assertEquals("Message successfully stored.", result);
    }

    // Send message choice: Invalid
    @Test
    public void testSendMessageInvalidOption() {
        Message msg = new Message("+27718693002", "Hello!", "Unknown");
        String result = msg.sendMessage("banana");
        assertEquals("Invalid option.", result);
    }
}